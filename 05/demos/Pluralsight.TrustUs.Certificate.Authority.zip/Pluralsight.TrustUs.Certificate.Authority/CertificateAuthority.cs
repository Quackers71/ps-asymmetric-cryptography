﻿using System.IO;
using Pluralsight.TrustUs.Data;
using Pluralsight.TrustUs.DataStructures;
using Pluralsight.TrustUs.Libraries;

namespace Pluralsight.TrustUs
{
    public class CertificateAuthority
    {
        public void SubmitCertificateRequest(CertificateAuthorityConfiguration certificateAuthorityConfiguration,
            string certificateRequestFileName)
        {

        }

        public void IssueCertificate(CertificateAuthorityConfiguration certificateAuthorityConfiguration,
            string certificateEmailAddress, string certificateFileName)
        {

        }
    }
}